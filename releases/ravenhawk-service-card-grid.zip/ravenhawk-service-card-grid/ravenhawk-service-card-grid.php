<?php
/**
 * Plugin Name: RavenHawk Service Card Grid
 * Plugin URI: https://ravenhawktech.com
 * Description: Adds neon RavenHawkTech service card grid blocks with editable title and style settings. Visit https://ravenhawktech.com for RavenHawkTech.
 * Version: 2.0.3
 * Author: RavenHawkTech
 */

if (!defined('ABSPATH')) exit;

define('RHT_SCG_VERSION', '2.0.3');
define('RHT_SCG_OPTION_KEY', 'rht_service_card_grid_options');

function rht_scg_defaults() {
    return array(
        'section_title' => 'Featured Services',
        'show_section_title' => '1',
        'glow_color' => '#39ff14',
        'card_background_color' => '#0a0a0a',
        'card_border_color' => '#39ff14',
        'card_hover_color' => '#b6ff00',
        'text_color' => '#f4fff0',
        'button_start_color' => '#39ff14',
        'button_end_color' => '#b6ff00',
        'button_text_color' => '#041004',
        'image_background_color' => '#070907',
        'gap' => 24,
        'card_radius' => 20,
    );
}

function rht_scg_options() {
    $saved = get_option(RHT_SCG_OPTION_KEY, array());
    return wp_parse_args(is_array($saved) ? $saved : array(), rht_scg_defaults());
}

function rht_scg_sanitize_options($input) {
    $defaults = rht_scg_defaults();
    $input = is_array($input) ? $input : array();
    $out = array();

    $out['section_title'] = sanitize_text_field($input['section_title'] ?? $defaults['section_title']);
    $out['show_section_title'] = !empty($input['show_section_title']) ? '1' : '0';

    foreach (array(
        'glow_color',
        'card_background_color',
        'card_border_color',
        'card_hover_color',
        'text_color',
        'button_start_color',
        'button_end_color',
        'button_text_color',
        'image_background_color',
    ) as $key) {
        $color = sanitize_hex_color($input[$key] ?? $defaults[$key]);
        $out[$key] = $color ?: $defaults[$key];
    }

    $out['gap'] = min(80, max(0, absint($input['gap'] ?? $defaults['gap'])));
    $out['card_radius'] = min(80, max(0, absint($input['card_radius'] ?? $defaults['card_radius'])));

    return $out;
}

function rht_scg_hex_to_rgb($hex) {
    $hex = ltrim((string) $hex, '#');

    if (strlen($hex) === 3) {
        $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
    }

    if (strlen($hex) !== 6) {
        return '57,255,20';
    }

    return hexdec(substr($hex, 0, 2)) . ',' . hexdec(substr($hex, 2, 2)) . ',' . hexdec(substr($hex, 4, 2));
}

function rht_scg_inline_css() {
    $opts = rht_scg_options();
    $glow_rgb = rht_scg_hex_to_rgb($opts['glow_color']);
    $border_rgb = rht_scg_hex_to_rgb($opts['card_border_color']);
    $text_rgb = rht_scg_hex_to_rgb($opts['text_color']);

    return '.rht-service-grid-wrap{' .
        '--rht-scg-glow:' . esc_html($opts['glow_color']) . ';' .
        '--rht-scg-glow-rgb:' . esc_html($glow_rgb) . ';' .
        '--rht-scg-card-bg:' . esc_html($opts['card_background_color']) . ';' .
        '--rht-scg-border:' . esc_html($opts['card_border_color']) . ';' .
        '--rht-scg-border-rgb:' . esc_html($border_rgb) . ';' .
        '--rht-scg-hover:' . esc_html($opts['card_hover_color']) . ';' .
        '--rht-scg-text:' . esc_html($opts['text_color']) . ';' .
        '--rht-scg-text-rgb:' . esc_html($text_rgb) . ';' .
        '--rht-scg-button-start:' . esc_html($opts['button_start_color']) . ';' .
        '--rht-scg-button-end:' . esc_html($opts['button_end_color']) . ';' .
        '--rht-scg-button-text:' . esc_html($opts['button_text_color']) . ';' .
        '--rht-scg-image-bg:' . esc_html($opts['image_background_color']) . ';' .
        '--rht-scg-gap:' . absint($opts['gap']) . 'px;' .
        '--rht-scg-radius:' . absint($opts['card_radius']) . 'px;' .
    '}';
}

function ravenhawk_service_card_grid_register() {
    wp_register_script(
        'ravenhawk-service-card-grid-blocks',
        plugins_url('blocks.js', __FILE__),
        array('wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components'),
        filemtime(plugin_dir_path(__FILE__) . 'blocks.js')
    );

    wp_register_style(
        'ravenhawk-service-card-grid-style',
        plugins_url('style.css', __FILE__),
        array(),
        filemtime(plugin_dir_path(__FILE__) . 'style.css')
    );
    wp_add_inline_style('ravenhawk-service-card-grid-style', rht_scg_inline_css());

    register_block_type('ravenhawk/service-card-grid', array(
        'editor_script'   => 'ravenhawk-service-card-grid-blocks',
        'editor_style'    => 'ravenhawk-service-card-grid-style',
        'style'           => 'ravenhawk-service-card-grid-style',
        'render_callback' => 'rht_scg_render_grid',
    ));

    register_block_type('ravenhawk/service-card', array(
        'editor_script' => 'ravenhawk-service-card-grid-blocks',
        'editor_style'  => 'ravenhawk-service-card-grid-style',
        'style'         => 'ravenhawk-service-card-grid-style',
    ));
}
add_action('init', 'ravenhawk_service_card_grid_register');

function rht_scg_render_grid($attributes, $content) {
    $opts = rht_scg_options();
    $title = trim((string) ($opts['section_title'] ?? ''));
    $show_title = ($opts['show_section_title'] ?? '1') === '1';

    ob_start();
    ?>
    <section class="rht-service-grid-wrap">
        <?php if ($show_title && $title !== ''): ?>
            <h2 class="rht-service-grid-title"><?php echo esc_html($title); ?></h2>
        <?php endif; ?>
        <?php echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
    </section>
    <?php
    return ob_get_clean();
}

function rht_scg_register_settings() {
    register_setting('rht_scg_settings', RHT_SCG_OPTION_KEY, array(
        'type' => 'array',
        'sanitize_callback' => 'rht_scg_sanitize_options',
        'default' => rht_scg_defaults(),
    ));
}
add_action('admin_init', 'rht_scg_register_settings');

function rht_scg_admin_menu_slug_exists($slug) {
    global $menu;

    if (!is_array($menu)) {
        return false;
    }

    foreach ($menu as $item) {
        if (isset($item[2]) && $item[2] === $slug) {
            return true;
        }
    }

    return false;
}

function rht_scg_admin_icon_url() {
    $path = plugin_dir_path(__FILE__) . 'assets/rht-admin-menu-icon.png';
    return file_exists($path) ? plugin_dir_url(__FILE__) . 'assets/rht-admin-menu-icon.png' : 'dashicons-grid-view';
}

function rht_scg_heading_icon_url() {
    $path = plugin_dir_path(__FILE__) . 'assets/rht-admin-heading-icon.png';
    return file_exists($path) ? plugin_dir_url(__FILE__) . 'assets/rht-admin-heading-icon.png' : '';
}

function rht_scg_admin_menu() {
    if (!rht_scg_admin_menu_slug_exists('ravenhawktech')) {
        add_menu_page(
            'RavenHawkTech',
            'RavenHawkTech',
            'manage_options',
            'ravenhawktech',
            'rht_scg_ravenhawktech_page',
            rht_scg_admin_icon_url(),
            81
        );
    }

    add_submenu_page(
        'ravenhawktech',
        'Service Card Grid',
        'Service Card Grid',
        'manage_options',
        'ravenhawk-service-card-grid',
        'rht_scg_settings_page'
    );
}
add_action('admin_menu', 'rht_scg_admin_menu');

function rht_scg_ravenhawktech_page() {
    if (!current_user_can('manage_options')) {
        return;
    }
    $icon_url = rht_scg_heading_icon_url();
    ?>
    <div class="wrap">
        <h1>
            <?php if ($icon_url): ?>
                <img src="<?php echo esc_url($icon_url); ?>" alt="" style="width:20px;height:20px;vertical-align:text-bottom;margin-right:6px;">
            <?php endif; ?>
            <a href="https://ravenhawktech.com" target="_blank" rel="noopener noreferrer">RavenHawkTech</a>
        </h1>
        <p>RavenHawkTech WordPress tools and connectors.</p>
        <p><a class="button button-primary" href="https://ravenhawktech.com" target="_blank" rel="noopener noreferrer">Visit RavenHawkTech</a></p>
    </div>
    <?php
}

function rht_scg_settings_page() {
    if (!current_user_can('manage_options')) {
        return;
    }

    $opts = rht_scg_options();
    $active_tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'general';
    if (!in_array($active_tab, array('general', 'style'), true)) {
        $active_tab = 'general';
    }
    ?>
    <div class="wrap">
        <h1>RavenHawk Service Card Grid</h1>
        <p>Basic service card grid settings. Visit <a href="https://ravenhawktech.com" target="_blank" rel="noopener noreferrer">RavenHawkTech</a>.</p>

        <h2 class="nav-tab-wrapper">
            <a href="<?php echo esc_url(admin_url('admin.php?page=ravenhawk-service-card-grid&tab=general')); ?>" class="nav-tab <?php echo $active_tab === 'general' ? 'nav-tab-active' : ''; ?>">General Settings</a>
            <a href="<?php echo esc_url(admin_url('admin.php?page=ravenhawk-service-card-grid&tab=style')); ?>" class="nav-tab <?php echo $active_tab === 'style' ? 'nav-tab-active' : ''; ?>">Style / Colors</a>
        </h2>

        <form method="post" action="options.php">
            <?php settings_fields('rht_scg_settings'); ?>

            <?php if ($active_tab === 'general'): ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="rht-scg-section-title">Section Title</label></th>
                        <td>
                            <input id="rht-scg-section-title" type="text" name="<?php echo esc_attr(RHT_SCG_OPTION_KEY); ?>[section_title]" value="<?php echo esc_attr($opts['section_title']); ?>" class="regular-text">
                            <p class="description">Displayed above each Service Card Grid block.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Show Section Title</th>
                        <td>
                            <label>
                                <input type="checkbox" name="<?php echo esc_attr(RHT_SCG_OPTION_KEY); ?>[show_section_title]" value="1" <?php checked($opts['show_section_title'], '1'); ?>>
                                Show the title above the grid.
                            </label>
                        </td>
                    </tr>
                </table>
                <?php submit_button('Save General Settings'); ?>
            <?php else: ?>
                <table class="form-table" role="presentation">
                    <?php
                    $color_fields = array(
                        'glow_color' => 'Glow / heading color',
                        'card_background_color' => 'Card background color',
                        'card_border_color' => 'Card border color',
                        'card_hover_color' => 'Hover accent color',
                        'text_color' => 'Text color',
                        'button_start_color' => 'Button gradient start',
                        'button_end_color' => 'Button gradient end',
                        'button_text_color' => 'Button text color',
                        'image_background_color' => 'Image background color',
                    );

                    foreach ($color_fields as $key => $label): ?>
                        <tr>
                            <th scope="row"><label for="rht-scg-<?php echo esc_attr($key); ?>"><?php echo esc_html($label); ?></label></th>
                            <td>
                                <input id="rht-scg-<?php echo esc_attr($key); ?>" type="color" name="<?php echo esc_attr(RHT_SCG_OPTION_KEY); ?>[<?php echo esc_attr($key); ?>]" value="<?php echo esc_attr($opts[$key]); ?>">
                                <code><?php echo esc_html($opts[$key]); ?></code>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <tr>
                        <th scope="row"><label for="rht-scg-gap">Grid gap</label></th>
                        <td><input id="rht-scg-gap" type="number" min="0" max="80" name="<?php echo esc_attr(RHT_SCG_OPTION_KEY); ?>[gap]" value="<?php echo esc_attr($opts['gap']); ?>"> px</td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="rht-scg-card-radius">Card border radius</label></th>
                        <td><input id="rht-scg-card-radius" type="number" min="0" max="80" name="<?php echo esc_attr(RHT_SCG_OPTION_KEY); ?>[card_radius]" value="<?php echo esc_attr($opts['card_radius']); ?>"> px</td>
                    </tr>
                </table>
                <?php submit_button('Save Style / Colors'); ?>
            <?php endif; ?>
        </form>
    </div>
    <?php
}
