
(function(blocks, element, blockEditor, components) {
    var el = element.createElement;
    var InnerBlocks = blockEditor.InnerBlocks;
    var InspectorControls = blockEditor.InspectorControls;
    var MediaUpload = blockEditor.MediaUpload;
    var RichText = blockEditor.RichText;
    var PanelBody = components.PanelBody;
    var RangeControl = components.RangeControl;
    var TextControl = components.TextControl;
    var ToggleControl = components.ToggleControl;
    var Button = components.Button;

    blocks.registerBlockType('ravenhawk/service-card-grid', {
        title: 'RavenHawk Service Card Grid',
        icon: 'grid-view',
        category: 'widgets',
        supports: { align: ['wide', 'full'] },
        attributes: {
            columns: { type: 'number', default: 3 }
        },
        edit: function(props) {
            var columns = props.attributes.columns || 3;
            var template = [
                ['ravenhawk/service-card', { title: 'Homelabs', text: 'Build, test, and document real-world lab environments.' }],
                ['ravenhawk/service-card', { title: 'Security', text: 'Cybersecurity tutorials, hardening, and awareness.' }],
                ['ravenhawk/service-card', { title: 'Tech Tutorials', text: 'Practical guides for Windows, Linux, networking, and more.' }]
            ];

            return [
                el(InspectorControls, {},
                    el(PanelBody, { title: 'Grid Settings', initialOpen: true },
                        el(RangeControl, {
                            label: 'Desktop Columns',
                            value: columns,
                            min: 2,
                            max: 4,
                            onChange: function(value) {
                                props.setAttributes({ columns: value });
                            }
                        })
                    )
                ),
                el('div', { className: 'rht-service-grid rht-columns-' + columns },
                    el(InnerBlocks, {
                        allowedBlocks: ['ravenhawk/service-card'],
                        template: template,
                        orientation: 'horizontal',
                        renderAppender: InnerBlocks.ButtonBlockAppender
                    })
                )
            ];
        },
        save: function(props) {
            var columns = props.attributes.columns || 3;
            return el('div', { className: 'rht-service-grid rht-columns-' + columns },
                el(InnerBlocks.Content)
            );
        }
    });

    blocks.registerBlockType('ravenhawk/service-card', {
        title: 'RavenHawk Service Card',
        icon: 'format-image',
        category: 'widgets',
        parent: ['ravenhawk/service-card-grid'],
        attributes: {
            title: { type: 'string', default: 'Service Title' },
            text: { type: 'string', default: 'Describe this service or category.' },
            imageUrl: { type: 'string', default: '' },
            buttonText: { type: 'string', default: 'Learn More' },
            buttonUrl: { type: 'string', default: '#' },
            newTab: { type: 'boolean', default: false }
        },
        edit: function(props) {
            var attrs = props.attributes;

            return [
                el(InspectorControls, {},
                    el(PanelBody, { title: 'CTA Button', initialOpen: true },
                        el(TextControl, {
                            label: 'Button Text',
                            value: attrs.buttonText,
                            onChange: function(value) { props.setAttributes({ buttonText: value }); }
                        }),
                        el(TextControl, {
                            label: 'Button URL',
                            value: attrs.buttonUrl,
                            onChange: function(value) { props.setAttributes({ buttonUrl: value }); }
                        }),
                        el(ToggleControl, {
                            label: 'Open in new tab',
                            checked: attrs.newTab,
                            onChange: function(value) { props.setAttributes({ newTab: value }); }
                        })
                    )
                ),
                el('div', { className: 'rht-service-card' },
                    el('div', { className: 'rht-service-card-image-wrap' },
                        attrs.imageUrl
                            ? el('img', { className: 'rht-service-card-image', src: attrs.imageUrl, alt: '' })
                            : el('div', { className: 'rht-service-card-placeholder' }, 'Square Image'),
                        el(MediaUpload, {
                            onSelect: function(media) { props.setAttributes({ imageUrl: media.url }); },
                            allowedTypes: ['image'],
                            render: function(obj) {
                                return el(Button, {
                                    onClick: obj.open,
                                    isPrimary: true,
                                    className: 'rht-media-button'
                                }, attrs.imageUrl ? 'Replace Image' : 'Select Image');
                            }
                        })
                    ),
                    el('div', { className: 'rht-service-card-content' },
                        el(RichText, {
                            tagName: 'h3',
                            value: attrs.title,
                            placeholder: 'Service Title',
                            onChange: function(value) { props.setAttributes({ title: value }); }
                        }),
                        el(RichText, {
                            tagName: 'p',
                            value: attrs.text,
                            placeholder: 'Short service description...',
                            onChange: function(value) { props.setAttributes({ text: value }); }
                        }),
                        el('a', {
                            className: 'rht-service-card-button',
                            href: attrs.buttonUrl || '#'
                        }, attrs.buttonText || 'Learn More')
                    )
                )
            ];
        },
        save: function(props) {
            var attrs = props.attributes;
            return el('div', { className: 'rht-service-card' },
                el('div', { className: 'rht-service-card-image-wrap' },
                    attrs.imageUrl ? el('img', {
                        className: 'rht-service-card-image',
                        src: attrs.imageUrl,
                        alt: attrs.title || ''
                    }) : null
                ),
                el('div', { className: 'rht-service-card-content' },
                    el(RichText.Content, { tagName: 'h3', value: attrs.title }),
                    el(RichText.Content, { tagName: 'p', value: attrs.text }),
                    el('a', {
                        className: 'rht-service-card-button',
                        href: attrs.buttonUrl || '#',
                        target: attrs.newTab ? '_blank' : undefined,
                        rel: attrs.newTab ? 'noopener noreferrer' : undefined
                    }, attrs.buttonText || 'Learn More')
                )
            );
        }
    });
})(window.wp.blocks, window.wp.element, window.wp.blockEditor, window.wp.components);
